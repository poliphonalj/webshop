package webshop.Model.Order;

public enum PaymentType {
    CASH,
    BARION
}
