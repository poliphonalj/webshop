package webshop.Model.Product;

public enum Unit {
    CSOMAG,
    DARAB,
    KG,
    ÜVEG,
    LITER,
    FÉL_LITER,
    DECILITER,
    FÜRT,
    ZSÁK,
    ADAG,
    CSUPOR,
    DOBOZ
}
