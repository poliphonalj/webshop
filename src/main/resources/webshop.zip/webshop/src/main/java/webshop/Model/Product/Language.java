package webshop.Model.Product;

public enum Language {
    GERMAN,
    ENGLISH
}
