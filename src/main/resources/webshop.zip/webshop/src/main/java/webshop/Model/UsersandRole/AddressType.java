package webshop.Model.UsersandRole;

public enum AddressType {
    HOME_ADDRESS,
    DELIVERY_ADDRESS,
    BILLING_ADDRESS,
    WORKPLACE
}
