package webshop.Model.Orders;

public enum PaymentType {
    CASH,
    BARION,
    TERMINAL
}
