package webshop.Model.UsersandRole;

public enum PlaceType {
    UTCA, ÚT, TÉR, SAROK, DűlŐ, KÖZ, LEJTŐ, LÉPCSŐ, LIGET, SÉTÁNY, KÖRÖND, KÖRTÉR,  SOR, KÖRÚT, SUGÁRÚT
}
